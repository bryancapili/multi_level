<?php  
include "excess/notice.php";
include "config.php";
include "DAO.php";
session_start();
if ($_SESSION['userlevel']) {
	header('Location:admin.php');
} elseif ($_SESSION['userlevel']) {
	header('Location:users.php');
}	
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
			<title>LVCC Login Form</title>
			<script src="js/prefixfree.min.js"></script>
			<link href="css/style.css" rel='stylesheet' type='text/css'/>
			<link rel="stylesheet" type="text/css" href="css/login.css">
			<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
			<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
			<link rel="stylesheet" type="text/css" href="Bootstrap/getbootstrap.com/2.3.2/assets/css/bootstrap-responsive.css">
			<link rel="stylesheet" type="text/css" href="fonts/font.css">
			<link rel="style=sheet" type="text/css" href="fonts/font1.css">
	</head>
	<body>
		<div class="body"></div>
		<div class="grad"></div>
		<div class="header">
			<div><span>La Verdad Christian College</span></div>
		</div>
			<br>
		<div class="login">
			<form action="login.php" method="POST">
				<h1 style="font-family:Calibri; color:white;" id="login">Login form.</h1>
				<input id="login1" type="text" placeholder="Email Address" name="email"><br>
				<input id="login2" type="password" placeholder="Password" name="password"><br>
				<input id="login3" type="submit" value="Login"><br><br>
			</form>	
			<p id="cap" style="font-family:Calibri; color:white;" >Free sign up <button id="toggle" type="submit">Register</button>
			<p id="cap1" style="font-family:Calibri; color:white; margin-top:-10px; display:none;" >Go to <button id="toggle1" type="submit">Login</button><br>
			<form action="register.php" method="POST" style="display:none;" id="form">		
				<h1 style="font-family:Calibri; color:white; margin-top:-10px;" id="re">Register fill out.</h1>
				<input id="reg" type="text" placeholder="Firsname" name="Fname"><br>
				<input id="reg1" type="text" placeholder="Lastname" name="Lname" style="margin-top:10px;"><br>	
				<input id="reg2" type="email" placeholder="Email" name="Email"><br>	
				<input id="reg3" type="password" placeholder="Password" name="Pass"><br>
				<input id="reg4" type="password" placeholder="Confirm Password" name="Conf"><br>
				<span  id="val"></span>	
				<input id="reg5" type="submit" value="Register">
			</form>
		</div>
	</body>
</html>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script type="text/javascript" src="js/animate_form.js"></script>
<script type="text/javascript" src="js/jquery.1.10.2.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/scripts.js"></script>
<script type="text/javascript" src="js/scripts.js"></script>
<script type="text/javascript" src="js/validate.js"></script>
