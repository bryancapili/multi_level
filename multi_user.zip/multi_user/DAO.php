<?php  

class DAO {

	public static function loginUser($data1) {
		$query = "SELECT * FROM register WHERE email = '{$data1['key_email']}'
											        && password = '{$data1['key_password']}'";
		$result = mysql_query($query);			
		$fetch = mysql_fetch_assoc($result);
		$_SESSION['userlevel'] = $fetch['user_level'];
		$_SESSION['firstname'] = $fetch['fname'];
		$_SESSION['emailadd'] = $fetch['email'];
		if ($fetch) {
			return true;
		} else {
			return false;
		}
	}

	public static function Register($data) {
		$query = "INSERT INTO register(fname, 
									lname, 
									email, 
									password, 
									confirm_pass,
									user_level)
				VALUES('{$data['key_firstname']}',
						'{$data['key_lastname']}',
						'{$data['key_email']}',
						'{$data['key_password']}',
						'{$data['key_confirm_password']}',
						'{$data['key_user_level']}')
						";
		$result = mysql_query($query);
		if ($result != false) {
			return true;
		} else {
			return false;
		}
	}

	public static function news($data) {
		$query = "INSERT INTO news_table(headline, 
									date_news)
				VALUES('{$data['key_news']}',
						CURDATE())
						";
		$result = mysql_query($query);
		if ($result != false) {
			return true;
		} else {
			return false;
		}
	}

	public static function events($data) {
		$query = "INSERT INTO event_table(date_of_event, 
									description)
				VALUES('{$data['key_date']}',
						'{$data['key_event_text']}')";
		$result = mysql_query($query);
		if ($result != false) {
			return true;
		} else {
			return false;
		}
	}	

	public static function getNews() {
		$query = "SELECT headline, date_news FROM news_table ORDER BY id DESC LIMIT 2";
		$result = mysql_query($query);
		if ($result) {
			$row = mysql_fetch_assoc($result);
			return $row;
		} else {
			return false;
		}
	}

	public static function UpDate($record) {
		$sql = " UPDATE register SET 
		fname = '{$record['key_firstname']}',
		lname = '{$record['key_lastname']}',
		email = '{$record['key_email']}'
		WHERE id = '{$record['id']}'";
		$result = mysql_query($sql);
		if ($result) {
			return true;
		} else {
			return false;
		}
	}
	
	public static function count() {
		$query = "SELECT COUNT(fname) AS total FROM register WHERE user_level = 2";
		$result = mysql_query($query);			
		$fetch = mysql_fetch_assoc($result);
		return $fetch['total'];
	}

	public static function getAll() {	
		$sql = "SELECT * FROM register WHERE user_level = 2";
		$result= mysql_query($sql);

		if (mysql_num_rows($result) > 0) {
			$arry = array();
			while ($mi = mysql_fetch_assoc($result)) {
				$arry[] = $mi;
			}
				return $arry;
		} else {
			return false;
		}
	} 

	public static function GetId($id) {
		$q = "SELECT * FROM register WHERE id = '{$id}'" ;
		$r = mysql_query($q);
		return mysql_fetch_assoc($r);
	}

	public static function deleteId($id) {
		$sql = "DELETE FROM register WHERE id = '{$id}'";
		$result = mysql_query($sql);

		if ($result) {
			$query ="ALTER TABLE register AUTO_INCREMENT = 1";
			$result1 = mysql_query($query);
			if ($result1) {
				return true;
			} else {
				return false;
			}
		} else {
			false;
		}

	}

	public static function deleteEvent($id) {
		$sql = "DELETE FROM event_table WHERE id = '{$id}'";
		$result = mysql_query($sql);

		if ($result) {
			$query ="ALTER TABLE event_table AUTO_INCREMENT = 1";
			$result1 = mysql_query($query);
			if ($result1) {
				return true;
			} else {
				return false;
			}
		} else {
			false;
		}

	}

	public static function getAllByEmail($email) {	
		$sql = "SELECT * FROM register WHERE email = '{$email}'";
		$r = mysql_query($sql);
		return mysql_fetch_assoc($r);
	} 


	public static function getAllNews() {	
		$sql = "SELECT * FROM news_table ORDER BY id DESC LIMIT 2";
		$result= mysql_query($sql);

		if (mysql_num_rows($result) > 0) {
			$arry = array();
			while ($mi = mysql_fetch_assoc($result)) {
				$arry[] = $mi;
			}
				return $arry;
		} else {
			return false;
		}
	} 
	public static function getAllEvent() {	
		$sql = "SELECT * FROM event_table ORDER BY id DESC LIMIT 2";
		$result= mysql_query($sql);

		if (mysql_num_rows($result) > 0) {
			$arry = array();
			while ($mi = mysql_fetch_assoc($result)) {
				$arry[] = $mi;
			}
				return $arry;
		} else {
			return false;
		}
	} 
}

?>