<?php  
session_start();
$_SESSION['userlevel'];
header('Location:index.php');
session_destroy();

?>