<?php
include "config.php";
if(isset($_GET['s']) && $_GET['s'] != ''){
	$s = $_GET['s'];
	$sql = "SELECT * FROM `register` WHERE email LIKE '%$s%' || fname LIKE '%$s%' || lname LIKE '%$s%' AND user_level = 2";
	$result = mysql_query($sql);
	while($row = mysql_fetch_array($result)){
		// $url = $row['Searchlink'];
		$title = $row['email'];
		echo  "<a href='#'></a>";
		echo  $title . "<br>" ;
	}
}	

?>