<?php  
include "config.php";
include "DAO.php";
session_start();
if (!isset($_SESSION['userlevel'])) {
	header('Location:index.php');  
} elseif ($_SESSION['userlevel'] != 2) {
	header('Location:admin.php'); 
} elseif ($_SESSION['firstname'] != "Subscriber") {
	header('Location:Contributor.php'); 
}
$email = $_SESSION['emailadd'];
$record = DAO::getAllByEmail($email);
$result = DAO::getAllNews();
$result2 = DAO::getAllEvent();
?>

<html>
<head>
	<title><?php echo $_SESSION['firstname'];?> Page</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="Bootstrap/getbootstrap.com/2.3.2/assets/css/bootstrap-responsive.css">
</head>
	<body>
	<div class="container">
		<div class="navbar navbar-inverse">
			<h2 style = "color:white;text-align:center"><?php echo $_SESSION['firstname']; ?> Profile</h2>
			<hr>
		</div>
		<nav class="navbar navbar-inverse">
				<div class="container-fluid">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<li class="active"><a class="navbar-brand"  href="admin.php"><img src="images/home.png" style="height:15px; width:15px; margin-bottom:4px; "> HOME</a></li>
					</div>
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						<ul class="nav navbar-nav">

						</ul>
						<ul class="nav navbar-nav navbar-right">
							
							<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> OPTION <span class="caret"></span></a>
								<ul class="dropdown-menu">
									<li style="margin-left:10px; font-family:Calibri;">USE THIS SITE AS</li><hr>
									<li><a href="logout.php" style="color:red;"><img src="images/logout.png" style="height:15px; width:15px;"> Sign out</a></li>
									<li><a href="#" style="color:blue;"><img src="images/eye.png" style="height:15px; width:15px;"> Co-admin</a></li>
									<li role="separator" class="divider"></li>
									<li><a href="#"style="color:blue;"><?php echo $_SESSION['emailadd']; ?></a></li>
								</ul>
							</li>
						</ul>
					</div>
				</div>
			</nav>
		<div class = "well" style = "text-align:center">
			<div class="row">
  				<div class="col-xs-6">
  					<div class="panel panel-primary" style="width:500px; margin-left:10px;">
						<div class="panel-heading">
							<h3 class="panel-title" style="font-size: 16px;">
								Upcoming Events
							</h3>
						</div>
					</div>
					<div class="thumbnail" style="width:500px; margin-left:10px;">
						<h4>Ucoming Events&nbsp;<img src="images/pin.png" style="height:20px; width:20px; "></h4><hr>
						<table  style="margin-left:10px; ">
							<tr>
								<?php if($result2 != false){
									foreach ($result2 as $row2)	{?>
								<tbody>
									<td style="color:blue;"><?=$row2['description']; ?><br>will be on:<b><?=$row2['date_of_event'];?></b></b></p><hr></td>
									<td></td>
								</tbody>
								<?php  
									}
								} else {

								}
								?>	
							</tr>
						</table>
					</div>
  				</div>
  				<div class="col-xs-6">
  					<div class="panel panel-primary" style="width:500px;">
						<div class="panel-heading">
							<h3 class="panel-title" style="font-size: 16px;">
								Lates News
							</h3>
						</div>
					</div>
  					<div class="thumbnail" style="width:500px; ">
						<h4>Latest News&nbsp;<img src="images/pin.png" style="height:20px; width:20px; "></h4><hr>
						<!-- <h5>Date: <?= $news['date_news'];?></h5>
						<a href="#"><?= $news['headline'];?></a> -->
						<table  style="margin-left:10px; ">
							<tr>
							
								<?php if($result != false){
									foreach ($result as $row)	{?>
								<tbody>
									<td style="color:blue;"><?=$row['headline']; ?><br><b>Created On:</b> <?=$row['date_news'];?><hr></td>
									<td></td>
								</tbody>
								<?php  
									}
								} else {

								}
								?>	
							</tr>
						</table>
					</div>
  				</div>
			</div>
		</div>
	</div>
	</body>
</html>
<script type="text/javascript" src="js/jquery.1.10.2.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/scripts.js"></script>
<script type="text/javascript" src="js/scripts.js"></script>
