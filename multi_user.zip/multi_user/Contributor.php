<?php  
include "config.php";
include "DAO.php";
session_start();
if (!isset($_SESSION['userlevel'])) {
	header('Location:index.php');  
} elseif ($_SESSION['userlevel'] != 2) {
	header('Location:admin.php'); 
} elseif ($_SESSION['firstname'] != "Contributor") {
	header('Location:Subscriber.php'); 
}
$email = $_SESSION['emailadd'];
$record = DAO::getAllByEmail($email);
$result = DAO::getAllNews();
$result2 = DAO::getAllEvent();
?>

<html>
<head>
	<title><?php echo $_SESSION['firstname'];?> Page</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="Bootstrap/getbootstrap.com/2.3.2/assets/css/bootstrap-responsive.css">
</head>
	<body>
	<div class="container">
		<div class="navbar navbar-inverse">
			<h2 style = "color:white;text-align:center"><?php echo $_SESSION['firstname']; ?> Profile</h2>
			<hr>
		</div>
		<nav class="navbar navbar-inverse">
				<div class="container-fluid">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<li class="active"><a class="navbar-brand"  href="admin.php"><img src="images/home.png" style="height:15px; width:15px; margin-bottom:4px; "> HOME</a></li>
					</div>
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						<ul class="nav navbar-nav">

							<li><a href="#news"  data-toggle="modal">NEWS<span class="sr-only">(current)</span></a></li>
							<li><a href="#events" data-toggle="modal">EVENTS</a></li>

						</ul>
						<ul class="nav navbar-nav navbar-right">
							
							<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> OPTION <span class="caret"></span></a>
								<ul class="dropdown-menu">
									<li style="margin-left:10px; font-family:Calibri;">USE THIS SITE AS</li><hr>
									<li><a href="logout.php" style="color:red;"><img src="images/logout.png" style="height:15px; width:15px;"> Sign out</a></li>
									<!-- <li><a href="#" style="color:blue;"><img src="images/eye.png" style="height:15px; width:15px;"> Co-admin</a></li> -->
									<li role="separator" class="divider"></li>
									<li><a href="#"style="color:blue;"><?php echo $_SESSION['emailadd']; ?></a></li>
								</ul>
							</li>
						</ul>
					</div>
				</div>
			</nav>
		<div class = "well">
			<div class="row">
  				<div class="col-xs-6">
  					<div class="panel panel-primary" style="width:500px; margin-left:10px;">
						<div class="panel-heading">
							<h3 class="panel-title" style="font-size: 16px;">
								Upcoming Events
							</h3>
						</div>
					</div>
					<div class="thumbnail" style="width:500px; margin-left:10px;">
						<h4>Ucoming Events&nbsp;<img src="images/pin.png" style="height:20px; width:20px; "></h4><hr>
						<table  style="margin-left:10px; ">
							<tr>
								<?php if($result2 != false){
									foreach ($result2 as $row2)	{?>
								<tbody>
									<td style="color:blue;"><?=$row2['description']; ?><br>will be on:<b><?=$row2['date_of_event'];?></b><br><br><a href="viewAsCon.php?id=<?=$row2['id'];?>">View</a>&nbsp; | <a href="delete.php?id=<?=$row2['id'];?>" style="color:red;">Delete</a></b></p><hr></td>
									<td></td>
								</tbody>
								<?php  
									}
								} else {

								}
								?>	
							</tr>
						</table>
					</div>
  				</div>
  				<div class="col-xs-6">
  					<div class="panel panel-primary" style="width:500px;">
						<div class="panel-heading">
							<h3 class="panel-title" style="font-size: 16px;">
								Lates News
							</h3>
						</div>
					</div>
  					<div class="thumbnail" style="width:500px; ">
						<h4>Latest News&nbsp;<img src="images/pin.png" style="height:20px; width:20px; "></h4><hr>
						<table  style="margin-left:10px; ">
							<tr>
							
								<?php if($result != false){
									foreach ($result as $row)	{?>
								<tbody>
									<td style="color:blue;"><?=$row['headline']; ?><br><b>Created On:</b> <?=$row['date_news'];?><hr></td>
									<td></td>
								</tbody>
								<?php  
									}
								} else {

								}
								?>	
							</tr>
						</table>
					</div>
  				</div>
			</div>
		</div>
		<div class="modal fade" id="news" >
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
						<p style="font-family:Calibri; font-size:30px;">Create News <img src="images/news.png" style="height:30px; width:30px; "> |
							<img src="images/news1.png" style="height:30px; width:30px; "> |
							<img src="images/news2.png" style="height:30px; width:30px; "> 
						</p>
					</div>
					<div class="modal-body">
						<form action="admin/news.php" method="POST">
								<label for="comment">Make a headline : </label>
  								<textarea class="form-control" rows="5" id="comment" name="text_news"></textarea>
							</div>
							<div class="modal-footer">		
								<button type="submit" class="btn btn-success" onclick="alert('Make sure that values has been set.');"  href="admin/news.php">Add</button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
		<div class="modal fade" id="events" >
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
						<p style="font-family:Calibri; font-size:30px;">Create Events <img src="images/event.png" style="height:30px; width:30px; "> </p>
					</div>
					<div class="modal-body">
						<form action="admin/event.php" method="POST">
								<label for="comment">Date of event: </label>
								<input type="date" class="form-control" name="date_name">
								<label for="comment">Specify event: </label>
  								<textarea class="form-control" rows="3" id="comment" name="text_name"></textarea>
							</div>
							<div class="modal-footer">		
								<button type="submit" class="btn btn-info"  href="admin/event.php">Post this event</button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>
</html>
<script type="text/javascript" src="js/jquery.1.10.2.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/scripts.js"></script>
<script type="text/javascript" src="js/scripts.js"></script>
