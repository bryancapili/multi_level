<?php  
include "config.php";
include "DAO.php";
session_start();
if (!isset($_SESSION['userlevel'])) {
	header('Location:index.php');
} elseif ($_SESSION['userlevel'] != 1){
	header('Location:Contributor.php');
}

$result = DAO::getAllNews();

$result1 = DAO::getAllEvent();
?>
<html>
<head>
	<title><?php echo $_SESSION['firstname'];?> Page</title>
	<link href="css/style.css" rel='stylesheet' type='text/css' />
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="Bootstrap/getbootstrap.com/2.3.2/assets/css/bootstrap-responsive.css">
	<link rel="stylesheet" type="text/css" href="css/search.css">
</head>
<body>
	<div id="logo">
		<div id="admin" style="margin-left:5%;">
		</div>
			</div>
		<div class="container">
			<div id="Caption" style="">
				<table cellspacing="10">
					<tr>
						<td><h1 style="font-family:calibri;">Admin Panel</h1></td>
						<td><a href="#id"  data-toggle="modal" style="display:inline; margin-left:10px;">Add co-admin?<img src="images/add.png" style="height:50px; width:50px; margin-bottom:10px;"></a></td>
					</tr>
				</table>
			</div>
			<nav class="navbar navbar-inverse">
				<div class="container-fluid">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<li class="active"><a class="navbar-brand"  href="admin.php"><img src="images/home.png" style="height:15px; width:15px; margin-bottom:4px; "> HOME</a></li>
					</div>
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						<ul class="nav navbar-nav">
							<li><a href="#news"  data-toggle="modal"><img src="images/news.png" style="height:15px; width:15px; margin-bottom:4px; "> NEWS <span class="sr-only">(current)</span></a></li>
							<li><a href="#events" data-toggle="modal"><img src="images/event.png" style="height:15px; width:15px; margin-bottom:4px; "> EVENTS</a></li>
							<li><a href="admin/view_all.php"><img src="images/register.png" style="height:15px; width:15px; margin-bottom:4px; "> REGISTERED COUNTER <span class="badge" style="background-color: #3a87ad;"><?php $count = DAO::count(); echo $count; ?></span> </a></li>	
						</ul>
						<form class="navbar-form navbar-left" role="search">
							<div class="form-group">
								<input type="text" class="form-control" placeholder="Search person." onkeyup="search(this.value)" id="text">
							</div>
							<img src="images/search.png" style="height:30px; width:30px; ">
						</form>
						<ul class="nav navbar-nav navbar-right">
							<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="images/other.png" style="height:15px; width:15px; margin-bottom:4px; "> OTHERS <span class="caret"></span></a>
								<ul class="dropdown-menu">
									<li><a href="#">Action</a></li>
									<li><a href="#">Another action</a></li>
									<li><a href="#">Something else here</a></li>
									<li role="separator" class="divider"></li>
									<li><a href="#">Separated link</a></li>
									<li role="separator" class="divider"></li>
									<li><a href="#">One more separated link</a></li>
								</ul>
							</li>
							<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="images/option.png" style="height:15px; width:15px; margin-bottom:4px; "> OPTION <span class="caret"></span></a>
								<ul class="dropdown-menu">
									<li style="margin-left:10px; font-family:Calibri;">USE THIS SITE AS</li><hr>
									<li><a href="logout.php" style="color:red;"><img src="images/logout.png" style="height:15px; width:15px;"> Sign out</a></li>
									<li><a href="admin/co-admin.php" style="color:blue;"><img src="images/eye.png" style="height:15px; width:15px;"> Co-admin</a></li>
									<li role="separator" class="divider"></li>
									<li><a href="#"style="color:blue;"><?php echo $_SESSION['emailadd']; ?></a></li>
								</ul>
							</li>
						</ul>
					</div>
				</div>
			</nav>
			
			<div class="row clearfix">
				<div class="col-md-6 column">
					<hr>
					<div class="jumbotron"  style="margin-left:14px;margin-right: 10px;">
						<h1 style="font-family:calibri;">Welcome <span class="name"><?php echo $_SESSION['firstname']; ?>!</span></h1>
						<p style="font-family:calibri;">Wisdom based on the truth is priceless.</p>
					</div>
					<hr>
				</div>
				<div class="col-md-6 column">
					<div class="row">
						<div class="col-md-6">
							<div class="thumbnail" style="margin-right: -15px;">
								<h4><p style="font-family:Calibri;"><img src="images/eye.png" style="height:20px;  width:20px; "> | See who else is registered  </p></h4><hr>
								<div id="search"></div>
								<hr>
							</div>
						</div>
						<div class="col-md-6">
							<div class="thumbnail" style="margin-right: -15px;">
								<h4>Upcoming Events&nbsp;<img src="images/pin.png" style="height:20px; width:20px; "></h4><hr>
								<table  style="margin-left:10px; ">
									<tr>
										<?php if($result1 != false){
											foreach ($result1 as $rows)	{?>
										<tbody>
											<td style="color:blue; "><p style="font-family:Calibri;"><?=$rows['description']; ?><br>will be on: <b><?=$rows['date_of_event'];?> 
												&nbsp;&nbsp;<a href="view.php?id=<?=$rows['id'];?>">View</a>&nbsp; | <a href="delete.php?id=<?=$rows['id'];?>" style="color:red;">Delete</a></b></p><hr></td>
											<td></td>
 										</tbody>
										<?php  
											}
										} else {

										}
										?>	
									</tr>
								</table>
							</div>
							<div class="thumbnail" style="margin-right: -50px;">
								<h4>Latest News&nbsp;<img src="images/pin.png" style="height:20px; width:20px; "></h4><hr>
								<!-- <h5>Date: <?= $news['date_news'];?></h5>
								<a href="#"><?= $news['headline'];?></a> -->
								<table  style="margin-left:10px; ">
									<tr>
									
										<?php if($result != false){
											foreach ($result as $row)	{?>
										<tbody>
											<td style="color:blue;"><?=$row['headline']; ?><br><b>Created On:</b> <?=$row['date_news'];?><hr></td>
											<td></td>
										</tbody>
										<?php  
											}
										} else {

										}
										?>	
									</tr>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="modal fade" id="id" >
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
						<p style="font-family:Calibri; font-size:30px; ">Add co-admin</p>
					</div>
					<div class="modal-body">
						<form action="admin/register.php" method="POST">
								<label for="exampleInputEmail1">Firstname</label>
								<input  type="text" id="fname" class="form-control"  name="Fname" required>
								<label for="exampleInputEmail1">Lastname</label>
								<input  type="text" id="lname" class="form-control"  name="Lname" required>
								<label for="exampleInputEmail1">Email</label>
								<input  type="email" id="email" class="form-control"  name="Email" required>
								<span class="red" id="PASSWORD"><label for="exampleInputEmail1">Password</label></span>
								<input  type="password" id="Pass" class="form-control"  name="Pass" >
								<span class="red" id="CONFIRM_PASSWORD"><label for="exampleInputEmail1">Confirm Password</label></span>
								<input  type="password" id="Con_pass" class="form-control"  name="Conf">
							</div>
							<div class="modal-footer">		
								<button type="submit" class="btn btn-success"  href="register.php">Add</button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>	
		<div class="modal fade" id="news" >
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
						<p style="font-family:Calibri; font-size:30px;">Create News <img src="images/news.png" style="height:30px; width:30px; "> |
							<img src="images/news1.png" style="height:30px; width:30px; "> |
							<img src="images/news2.png" style="height:30px; width:30px; "> 
						</p>
					</div>
					<div class="modal-body">
						<form action="admin/news.php" method="POST">
								<label for="comment">Make a headline : </label>
  								<textarea class="form-control" rows="5" id="comment" name="text_news"></textarea>
							</div>
							<div class="modal-footer">		
								<button type="submit" class="btn btn-success" onclick="alert('Make sure that values has been set.');"  href="admin/news.php">Add</button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
		<div class="modal fade" id="events" >
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
						<p style="font-family:Calibri; font-size:30px;">Create Events <img src="images/event.png" style="height:30px; width:30px; "> </p>
					</div>
					<div class="modal-body">
						<form action="admin/event.php" method="POST">
								<label for="comment">Date of event: </label>
								<input type="date" class="form-control" name="date_name">
								<label for="comment">Specify event: </label>
  								<textarea class="form-control" rows="3" id="comment" name="text_name"></textarea>
							</div>
							<div class="modal-footer">		
								<button type="submit" class="btn btn-info"  href="admin/event.php">Post this event</button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
</body>
</html>
<script type="text/javascript" src="js/jquery.1.10.2.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/scripts.js"></script>
<script type="text/javascript" src="js/scripts.js"></script>
<script type="text/javascript" src="js/search.js"></script>
<script type="text/javascript" src="js/validate.js"></script>