-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 11, 2016 at 03:48 AM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `multi_level_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `event_table`
--

CREATE TABLE IF NOT EXISTS `event_table` (
  `id` int(123) NOT NULL AUTO_INCREMENT,
  `date_of_event` varchar(123) NOT NULL,
  `description` varchar(1234) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `event_table`
--

INSERT INTO `event_table` (`id`, `date_of_event`, `description`) VALUES
(1, '2016-03-16', 'Android Programming Seminar'),
(3, '2016-05-12', 'Computer Programming Competition'),
(4, '2016-03-11', 'Monthly Meeting');

-- --------------------------------------------------------

--
-- Table structure for table `news_table`
--

CREATE TABLE IF NOT EXISTS `news_table` (
  `id` int(123) NOT NULL AUTO_INCREMENT,
  `headline` varchar(1233) NOT NULL,
  `date_news` varchar(123) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `news_table`
--

INSERT INTO `news_table` (`id`, `headline`, `date_news`) VALUES
(1, 'La Verdad Christian College is the most popular college in the Pampanga.', '2016-02-19'),
(2, 'STUDY NOW....PAY NEVER\nQuality Education for FREE\nLA VERDAD CHRISTIAN COLLEGE - \nFULL SCHOLARSHIP GRANT FOR SCHOOL YEAR 201', '2016-02-19'),
(3, 'This is a sample\r\n', '2016-03-06'),
(4, 'Hi Im interview here by Sir Harry\r\n', '2016-03-08');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE IF NOT EXISTS `register` (
  `id` int(123) NOT NULL AUTO_INCREMENT,
  `fname` varchar(123) NOT NULL,
  `lname` varchar(123) NOT NULL,
  `email` varchar(123) NOT NULL,
  `password` varchar(123) NOT NULL,
  `confirm_pass` varchar(123) NOT NULL,
  `user_level` varchar(123) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `fname`, `lname`, `email`, `password`, `confirm_pass`, `user_level`) VALUES
(1, 'Admin', 'Admin', 'Admin@yahoo.com', 'admin123', 'admin123', '1'),
(2, 'Contributor', 'Contributor', 'Contributor@gmail.com', 'contributor', 'contributor', '2'),
(3, 'Subscriber', 'Subscriber', 'Subscriber@gmail.com', 'subscriber', 'subscriber', '2');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
