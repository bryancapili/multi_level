<?php  
include "config.php";
include "DAO.php";
session_start();
if (!isset($_SESSION['userlevel'])) {
	header('Location:index.php');  
} elseif ($_SESSION['userlevel'] != 2) {
	header('Location:admin.php'); 
} elseif ($_SESSION['firstname'] != "Contributor") {
	header('Location:Subscriber.php'); 
}
$email = $_SESSION['emailadd'];
$id = $_GET['id'];
$query = "SELECT * FROM event_table WHERE id = '{$id}'";
$result = mysql_query($query);

if (!empty($result)) {
	$record = mysql_fetch_array($result);
}

	
?>

<html>
<head>
	<title><?php echo $_SESSION['firstname'];?> Page</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="Bootstrap/getbootstrap.com/2.3.2/assets/css/bootstrap-responsive.css">
</head>
	<body>
	<div class="container">
		<div class="navbar navbar-inverse">
			<h2 style = "color:white;text-align:center"><?php echo $_SESSION['firstname']; ?> Profile</h2>
			<hr>
		</div>
		<nav class="navbar navbar-inverse">
				<div class="container-fluid">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<li class="active"><a class="navbar-brand"  href="admin.php"><img src="images/home.png" style="height:15px; width:15px; margin-bottom:4px; "> HOME</a></li>
					</div>
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						<ul class="nav navbar-nav">

							<li><a href="#news"  data-toggle="modal">NEWS<span class="sr-only">(current)</span></a></li>
							<li><a href="#events" data-toggle="modal">EVENTS</a></li>

						</ul>
						<ul class="nav navbar-nav navbar-right">
							
							<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> OPTION <span class="caret"></span></a>
								<ul class="dropdown-menu">
									<li style="margin-left:10px; font-family:Calibri;">USE THIS SITE AS</li><hr>
									<li><a href="logout.php" style="color:red;"><img src="images/logout.png" style="height:15px; width:15px;"> Sign out</a></li>
									<!-- <li><a href="#" style="color:blue;"><img src="images/eye.png" style="height:15px; width:15px;"> Co-admin</a></li> -->
									<li role="separator" class="divider"></li>
									<li><a href="#"style="color:blue;"><?php echo $_SESSION['emailadd']; ?></a></li>
								</ul>
							</li>
						</ul>
					</div>
				</div>
			</nav>
		<div class = "well">
			<div class="row">
  				<div class="panel panel-primary" style="margin-left:auto; margin-right:auto; width:700px;">
				<div class="panel-heading">
					<h3 class="panel-title" style="font-size: 16px;">
						<?= $record['description']; ?>
					</h3>
				</div>
			</div>
			<div class="thumbnail" style="margin-left:auto; margin-right:auto; width:700px;">
				<h3>will held On <?=$record['date_of_event'];  ?></h3>
			</div>
			<center><a href="Contributor.php" class="btn btn-success">Back to previous page</a></center>
			</div>
		</div>
		
	</div>
</body>
</html>
<script type="text/javascript" src="js/jquery.1.10.2.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/scripts.js"></script>
<script type="text/javascript" src="js/scripts.js"></script>
