<?php  
include "../config.php";
include "../DAO.php";

$data = array(
	'key_news' => strip_tags($_POST['text_news'])
);
	if(!empty($_POST['text_news'])		
		){
		$result = DAO::news($data);
		if ($result == true) {
			header('Location:../admin.php'); 
		} else {
			echo "<h1>Error creating news.</h1>";
		}
	} else {
		echo '<h1>Error creating news.</h1>';
	}
?>