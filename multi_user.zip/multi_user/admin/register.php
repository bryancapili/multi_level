<?php  
include "../config.php";
include "../DAO.php";
$user_level = 1;
$data = array(
	'key_firstname' => strip_tags($_POST['Fname']),
	'key_lastname' => strip_tags($_POST['Lname']),
	'key_email' => strip_tags($_POST['Email']),
	'key_password' => strip_tags($_POST['Pass']),
	'key_confirm_password' => strip_tags($_POST['Conf']),
	'key_user_level' => $user_level
);
	if(!empty($_POST['Fname'])
		&& !empty($_POST['Lname'])
		&& !empty($_POST['Email'])
		&& !empty($_POST['Pass'])
		&& !empty($_POST['Conf'])
		){
		$result = DAO::Register($data);
		if ($result == true) {
			header('Location:../admin.php'); 
		} else {
			echo "<h1> Error registration. </h1>";
		}
	} else {
		echo '<h1> Access denied </h1>';
	}

?>