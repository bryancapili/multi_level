<?php  
include "../config.php";
include "../DAO.php";
session_start();
if (!isset($_SESSION['userlevel'])) {
	header('Location:../index.php');
} elseif ($_SESSION['userlevel'] != 1){
	header('Location:../users.php');
}

$count = DAO::count();
$result = DAO::getAll();

$result1 = DAO::getAllNews();

$result2 = DAO::getAllEvent();
?>
<html>
<head>
	<title>All Register</title>
	<link href="../css/style.css" rel='stylesheet' type='text/css' />
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../Bootstrap/getbootstrap.com/2.3.2/assets/css/bootstrap-responsive.css">
	<link rel="stylesheet" type="text/css" href="../css/search.css">
</head>
<body>
	<div id="logo">
		<div id="admin" style="margin-left:5%;">
		</div>
	</div>
		<div class="container">
			<div id="Caption" style="">
				<table cellspacing="10">
					<tr>
						<td><h1 style="font-family:calibri;">Admin Panel</h1></td>
						<td><a href="#add_CO"  data-toggle="modal" style="display:inline; margin-left:10px;">Add co-admin?<img src="../images/add.png" style="height:50px; width:50px; margin-bottom:10px; "></a></td>
					</tr>
				</table>
			</div>
			<nav class="navbar navbar-inverse">
				<div class="container-fluid">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="../admin.php"><img src="../images/home.png" style="height:15px; width:15px; margin-bottom:4px; "> HOME</a>
					</div>
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						<ul class="nav navbar-nav">

							<li class="active"><a href="view_all.php" ><img src="../images/register.png" style="height:15px; width:15px; margin-bottom:4px; "> REGISTERED COUNTER <span class="badge" style="background-color: #3a87ad;"><?php echo $count; ?></span></a></li>	
						</ul>
						<ul class="nav navbar-nav navbar-right">
							<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="../images/other.png" style="height:15px; width:15px; margin-bottom:4px; "> OTHERS <span class="caret"></span></a>
								<ul class="dropdown-menu">
									<li><a href="#">Action</a></li>
									<li><a href="#">Another action</a></li>
									<li><a href="#">Something else here</a></li>
									<li role="separator" class="divider"></li>
									<li><a href="#">Separated link</a></li>
									<li role="separator" class="divider"></li>
									<li><a href="#">One more separated link</a></li>
								</ul>
							</li>
							<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="../images/option.png" style="height:15px; width:15px; margin-bottom:4px; "> OPTION <span class="caret"></span></a>
								<ul class="dropdown-menu">
									<li style="margin-left:10px; font-family:Calibri;">USE THIS SITE AS</li><hr>
									<li><a href="../logout.php" style="color:red;"><img src="../images/logout.png" style="height:15px; width:15px;"> Sign out</a></li>
									<li><a href="#" style="color:blue;"><img src="../images/eye.png" style="height:15px; width:15px;"> Co-admin</a></li>
									<li role="separator" class="divider"></li>
									<li><a href="#"style="color:blue;"><?php echo $_SESSION['emailadd']; ?></a></li>
								</ul>
							</li>
						</ul>
					</div>
				</div>
			</nav>
			<div class="row clearfix">
				<div class="col-md-6 column">
					<h3 style="font-family:Calibri; margin-left:10px; ">List of Registered</h3>
					<table style="margin-left:10px;" border="10" class="table table-bordered">
							<tr>
								<thead>

									<th>Firstname</th>
									<th>Lastname</th>
									<th>Email</th>
									<th colspan="2">Action</th>
								</thead>
								<?php 
								if($result!= false) {
									foreach ($result as $row) {?>
									<tbody>

										<td><?=$row['fname']?></td>
										<td><?=$row['lname']?></td>
										<td width="30px;"><?=$row['email']?></td>
										<td><button class=" btn btn-info show-modal" href="#id" data-id='<?= $row['id']?>' data-toggle="modal" style="margin-bottom:10px;">Update</button> </td>
										<td><a id='edit' href="delete.php?id=<?= $row['id']?>" class="btn btn-danger">Delete</a> </td> 
									</tbody>
								<?php  }
									} else {

								} 
								 ?>
							</tr>
						</table>

				</div>
				<div class="col-md-6 column">
					<div class="row" style="margin-left:5px;">
						<div class="col-md-6">
							<div class="thumbnail" style="margin-right:-50px;">
								<h4>Latest News&nbsp;<img src="../images/pin.png" style="height:20px; width:20px; "></h4><hr>
								<table  style="margin-left:10px; ">
									<tr>
									
										<?php if($result1 != false){
											foreach ($result1 as $row1)	{?>
										<tbody>
											<td style="color:blue;"><?=$row1['headline']; ?><br><b>Created On:</b> <?=$row1['date_news'];?><hr></td>
											<td></td>
										</tbody>
										<?php  
											}
										} else {

										}
										?>	
									</tr>
								</table>
							</div>
						</div>
						<div class="col-md-6">
							<div class="thumbnail" style="margin-right: -15px;">
								<h4>Ucoming Events&nbsp;<img src="../images/pin.png" style="height:20px; width:20px; "></h4><hr>
								<table  style="margin-left:10px; ">
									<tr>
										<?php if($result2 != false){
											foreach ($result2 as $row2)	{?>
										<tbody>
											<td style="color:blue;"><?=$row2['description']; ?><br>will be on: <b><?=$row2['date_of_event'];?></b><hr></td>
											<td></td>
										</tbody>
										<?php  
											}
										} else {

										}
										?>	
									</tr>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>	
		<div class="modal fade" id="id" >
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
						<p style="font-family:Calibri; font-size:30px; ">Update User</p>
					</div>
					<div class="modal-body">
						<form action="update.php" method="POST">
								<input type = "hidden" name ="id" id ="this_id">

								<label for="exampleInputEmail1">Firstname</label>
								<input  type="text" id="fname" class="form-control"  name="Fname" >

								<label for="exampleInputEmail1">Lastname</label>
								<input  type="text" id="lname" class="form-control"  name="Lname" >

								<label for="exampleInputEmail1">Email</label>
								<input  type="email" id="email" class="form-control"  name="Email" >
							</div>
							<div class="modal-footer">		
								<button type="submit" class="btn btn-success"  href="update.php">update</button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
		<div class="modal fade" id="add_CO" >
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
						<p style="font-family:Calibri; font-size:30px; ">Add co-admin</p>
					</div>
					<div class="modal-body">
						<form action="register.php" method="POST">
								<label for="exampleInputEmail1">Firstname</label>
								<input  type="text" id="fname" class="form-control"  name="Fname" required>
								<label for="exampleInputEmail1">Lastname</label>
								<input  type="text" id="lname" class="form-control"  name="Lname" required>
								<label for="exampleInputEmail1">Email</label>
								<input  type="email" id="email" class="form-control"  name="Email" required>
								<span class="red" id="PASSWORD"><label for="exampleInputEmail1">Password</label></span>
								<input  type="password" id="Pass" class="form-control"  name="Pass" >
								<span class="red" id="CONFIRM_PASSWORD"><label for="exampleInputEmail1">Confirm Password</label></span>
								<input  type="password" id="Con_pass" class="form-control"  name="Conf">
							</div>
							<div class="modal-footer">		
								<button type="submit" class="btn btn-success"  href="register.php">Add</button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>		
</body>
</html>
<script type="text/javascript" src="../js/jquery.1.10.2.js"></script>
<script type="text/javascript" src="../js/bootstrap.min.js"></script>
<script type="text/javascript" src="../js/jquery.min.js"></script>
<script type="text/javascript" src="../js/scripts.js"></script>
<script type="text/javascript" src="../js/scripts.js"></script>
<script type="text/javascript" src="../js/search.js"></script>
<script type="text/javascript" src="../js/validate.js"></script>
