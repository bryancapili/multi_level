<?php  
include "../config.php";
include "../DAO.php";

$data = array(
	'key_date' => strip_tags($_POST['date_name']),
	'key_event_text' => strip_tags($_POST['text_name'])
);
	if(!empty($_POST['date_name']) && 
		!empty($_POST['text_name'])		
		){
		$result = DAO::events($data);
		if ($result == true) {
			header('Location:../admin.php'); 
		} else {
			echo "<h1>Error creating event.</h1>";
		}
	} else {
		echo '<h1>Error creating event.</h1>';
	}
?>