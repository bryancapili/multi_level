<?php
include "../config.php";
include "../DAO.php";

$id = $_GET['id'];
$result = DAO::deleteId($id);

if ($result == true) {
	header('Location:view_all.php');
} else {
	return false;
}


?>