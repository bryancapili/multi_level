<?php 
include "../config.php";
include "../DAO.php";

$record = array(
		'id' => $_POST['id'],
		'key_firstname' => $_POST['Fname'],
		'key_lastname' => $_POST['Lname'],
		'key_email' => $_POST['Email']
);
	
if(!empty($_POST['Fname']) 
	&& !empty($_POST['Lname'])
	&& !empty($_POST['Email'])) 
{
	$result = DAO::UpDate($record);
	if ($result == true) {
		header('Location:view_all.php');
	} else {
		echo"<h1>Update error!</h1>";

	}
} else {
	echo"<h1>Access denied.</h1>";

}

?>