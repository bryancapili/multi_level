<?php  

include "../config.php";
include "../DAO.php";
session_start();
if (!isset($_SESSION['userlevel'])) {
	header('Location:../index.php');
} elseif ($_SESSION['userlevel'] != 1){
	header('Location:../users.php');
}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
			<title>Co admin</title>
			<script src="js/prefixfree.min.js"></script>
			<link href="css/style.css" rel='stylesheet' type='text/css'/>
			<link rel="stylesheet" type="text/css" href="../css/login.css">
			<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
			<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
			<link rel="stylesheet" type="text/css" href="../Bootstrap/getbootstrap.com/2.3.2/assets/css/bootstrap-responsive.css">
			<link rel="stylesheet" type="text/css" href="../fonts/font.css">
			<link rel="stylesheet" type="text/css" href="../fonts/font1.css">
	</head>
	<body>
		<div class="container">
			<nav class="navbar navbar-inverse">
				<div class="container-fluid">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<li class="active"><a class="navbar-brand"  href="admin.php"><img src="../images/home.png" style="height:15px; width:15px; margin-bottom:4px; "> HOME</a></li>
					</div>
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						<ul class="nav navbar-nav">
							<li><a href="#news"  data-toggle="modal"><img src="../images/news.png" style="height:15px; width:15px; margin-bottom:4px; "> NEWS <span class="sr-only">(current)</span></a></li>
							<li><a href="#events" data-toggle="modal"><img src="../images/event.png" style="height:15px; width:15px; margin-bottom:4px; "> EVENTS</a></li>
							<li><a href="admin/view_all.php"><img src="../images/register.png" style="height:15px; width:15px; margin-bottom:4px; "> REGISTERED COUNTER <span class="badge" style="background-color: #3a87ad;"><?php $count = DAO::count(); echo $count; ?></span> </a></li>	
						</ul>
						<form class="navbar-form navbar-left" role="search">
							<div class="form-group">
								<input type="text" class="form-control" placeholder="Search person." onkeyup="search(this.value)" id="text">
							</div>
							<img src="../images/search.png" style="height:30px; width:30px; ">
						</form>
						<ul class="nav navbar-nav navbar-right">
							<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="../images/other.png" style="height:15px; width:15px; margin-bottom:4px; "> OTHERS <span class="caret"></span></a>
								<ul class="dropdown-menu">
									<li><a href="#">Action</a></li>
									<li><a href="#">Another action</a></li>
									<li><a href="#">Something else here</a></li>
									<li role="separator" class="divider"></li>
									<li><a href="#">Separated link</a></li>
									<li role="separator" class="divider"></li>
									<li><a href="#">One more separated link</a></li>
								</ul>
							</li>
							<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="../images/option.png" style="height:15px; width:15px; margin-bottom:4px; "> OPTION <span class="caret"></span></a>
								<ul class="dropdown-menu">
									<li style="margin-left:10px; font-family:Calibri;">USE THIS SITE AS</li><hr>
									<li><a href="logout.php" style="color:red;"><img src="../images/logout.png" style="height:15px; width:15px;"> Sign out</a></li>
									<li><a href="admin/co-admin.php" style="color:blue;"><img src="../images/eye.png" style="height:15px; width:15px;"> Co-admin</a></li>
									<li role="separator" class="divider"></li>
									<li><a href="#"style="color:blue;"><?php echo $_SESSION['emailadd']; ?></a></li>
								</ul>
							</li>
						</ul>
					</div>
				</div>
			</nav>
			
		</div>	
	</body>
</html>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script type="text/javascript" src="../js/animate_form.js"></script>
<script type="text/javascript" src="../js/jquery.1.10.2.js"></script>
<script type="text/javascript" src="../js/bootstrap.min.js"></script>
<script type="text/javascript" src="../js/jquery.min.js"></script>
<script type="text/javascript" src="../js/scripts.js"></script>
<script type="text/javascript" src="../js/scripts.js"></script>
<script type="text/javascript" src="../js/validate.js"></script>
