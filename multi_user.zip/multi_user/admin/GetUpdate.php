<?php 
include_once("../config.php");
include_once("../DAO.php");

$id = $_POST['name_id'];
$result = DAO::GetId($id);

echo json_encode(
		array(
			'Key_id' => $result['id'],
			'Key_fname' => $result['fname'],
			'Key_lname' => $result['lname'],
			'Key_email' => $result['email']
		)
)
?>