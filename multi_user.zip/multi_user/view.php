<?php  
include "config.php";
include "DAO.php";
session_start();
if (!isset($_SESSION['userlevel'])) {
	header('Location:index.php');
} elseif ($_SESSION['userlevel'] != 1){
	header('Location:Contributor.php');
}

$count = DAO::count();
$id = $_GET['id'];
$query = "SELECT * FROM event_table WHERE id = '{$id}'";
$result = mysql_query($query);

if (!empty($result)) {
	$record = mysql_fetch_array($result);
}


?>
<html>
<head>
	<title><?php echo $_SESSION['firstname'];?> Page</title>
	<link href="css/style.css" rel='stylesheet' type='text/css' />
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="Bootstrap/getbootstrap.com/2.3.2/assets/css/bootstrap-responsive.css">
	<link rel="stylesheet" type="text/css" href="css/search.css">
</head>
<body>
	<div id="logo">
		<div id="admin" style="margin-left:5%;">
		</div>
			</div>
		<div class="container">
			<div id="Caption" style="">
				<table cellspacing="10">
					<tr>
						<td><h1 style="font-family:calibri;">Admin Panel</h1></td>

					</tr>
				</table>
			</div>
			<nav class="navbar navbar-inverse">
				<div class="container-fluid">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<li class="active"><a class="navbar-brand"  href="admin.php"><img src="images/home.png" style="height:15px; width:15px; margin-bottom:4px; "> HOME</a></li>
					</div>
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						<ul class="nav navbar-nav">
							<li><a href="admin/view_all.php"><img src="images/register.png" style="height:15px; width:15px; margin-bottom:4px; "> REGISTERED COUNTER <span class="badge" style="background-color: #3a87ad;"><?php echo $count; ?></span> </a></li>	
						</ul>
						<ul class="nav navbar-nav navbar-right">
						
							<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="images/option.png" style="height:15px; width:15px; margin-bottom:4px; "> OPTION <span class="caret"></span></a>
								<ul class="dropdown-menu">
									<li style="margin-left:10px; font-family:Calibri;">USE THIS SITE AS</li><hr>
									<li><a href="logout.php" style="color:red;"><img src="images/logout.png" style="height:15px; width:15px;"> Sign out</a></li>
									<li><a href="#" style="color:blue;"><img src="images/eye.png" style="height:15px; width:15px;"> Co-admin</a></li>
									<li role="separator" class="divider"></li>
									<li><a href="#"style="color:blue;"><?php echo $_SESSION['emailadd']; ?></a></li>
								</ul>
							</li>
						</ul>
					</div>
				</div>
			</nav>
			<div class="panel panel-primary" style="margin-left:auto; margin-right:auto; width:700px;">
				<div class="panel-heading">
					<h3 class="panel-title" style="font-size: 16px;">
						<?= $record['description']; ?>
					</h3>
				</div>
			</div>
			<div class="thumbnail" style="margin-left:auto; margin-right:auto; width:700px;">
				<h3>will held On <?=$record['date_of_event'];  ?></h3>
			</div>
			<center><a href="admin.php" class="btn btn-success">Back to previous page</a></center>
		</div>
</body>
</html>
<script type="text/javascript" src="js/jquery.1.10.2.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/scripts.js"></script>
<script type="text/javascript" src="js/scripts.js"></script>
<script type="text/javascript" src="js/search.js"></script>
<script type="text/javascript" src="js/validate.js"></script>