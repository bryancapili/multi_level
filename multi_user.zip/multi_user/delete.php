<?php 
include "config.php";
include "DAO.php";

 $id = $_GET['id'];
 if(isset($id)){
 	$result = DAO::deleteEvent($id);
 	header("location:admin.php");
 }
?>