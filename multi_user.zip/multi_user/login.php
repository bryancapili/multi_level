<?php  
include "config.php";
include "DAO.php";
session_start();
$data1 = array(
	'key_email' => strip_tags($_POST['email']),
	'key_password' => strip_tags($_POST['password'])
	);
if (!empty($_POST['email']) && !empty($_POST['password'])) {
	$result = DAO::loginUser($data1);
	if ($result == true) {
		if ($_SESSION['userlevel'] == 1 ) {
			header('Location:admin.php');
		} elseif ($_SESSION['firstname'] == "Contributor") {
			header('Location:Contributor.php');
		} elseif ($_SESSION['firstname'] == "Subscriber") {
			header('Location:Subscriber.php');
		}
	} else {
		echo "<h1>The email or password number you've entered doesn't match any account..</h1>";
	}
} else {
 	echo "<h1>Fill out those fields..</h1>";
}
?>