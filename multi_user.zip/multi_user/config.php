<?php 
mysql_connect("localhost","root","") or die("Could not connect database");
mysql_select_db("multi_level_database") or die("Error database");
?>